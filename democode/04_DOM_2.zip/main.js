const button = document.getElementById('button');

// An eventlistener is a function that takes another
// function as an argument, 1 argument: 'click'
// 2 argument: anonymous function: callback
button.addEventListener('click', function () {
  sayHey("Bengt");
});

// With this we can't send arguments to the function
button.addEventListener('click', sayHey);


function sayHey() {
  console.log("Hello!");
}

// Global variable
const theStreets = true;
// Save the person being returned from houseB();
const bengt = houseB();
// Send along the person to houseA();
houseA(bengt);

function houseA(agneta) {
  // Every house can see the streets but not their neighbours.
  const personA = true;
  console.log(theStreets);
  console.log(personA);
  console.log(agneta);
}

function houseB() {
  const personB = true;
  console.log(theStreets);
  console.log(personB);
  return personB;
}

const houseC = function () {
  const personC = true;
}


const addParagraphButton = document.getElementById('addParagraphButton');
const a = 5;
const b = 10;

const form = document.getElementById('form');

// If we use a form we must make sure the default
// event is not triggered. The default behavior is that
// a form submit will reload the page. this is not what
// we want
form.addEventListener('submit', function (event) {
  // event.preventDefault(); makes sure the event is not triggered
  // we must also take this event as parameter in the function
  event.preventDefault();
  console.log(event);
})


const arr = [
  { name: "Jesper", age: 2000 },
  { name: "Anti-Jesper", age: 12 }
]

// Display the array in a nice table
console.table(arr);

// Name your console logs!
console.log('My a!' + a, a, b, a, b, a);
console.log('My b!', b);
// or colorize them!
console.log('%c' + a, 'background-color: red; color: white; font-size: 3rem; font-family: Comic Sans MS');