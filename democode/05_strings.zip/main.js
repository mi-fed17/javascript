const output = document.getElementById('output');

// Array of objects to loop through, two unnamed objects
// with the properties: title, content
const articles = [
  {
    title: `"På spåret"-chocken!!! Se bilderna`,
    content: `Fredagen slutade hemskt.`
  },
  {
    title: `Har du sett djuret Quokka?`,
    content: `Wow vilket djur!`
  }
];

// create an empty string that will hold all of the html
let htmlBlock = "";
// Loop through each object in the array
for(const article of articles){
  // Add it to the empty variable. For each article
  // take out the title and content with dot notation
  htmlBlock += `
    <section>
      <h2>${article.title}</h2>
      <p>${article.content}</p>
    </section>
  `;
}
// After the loop is done the variable 'htmlBlock' will
// contain all of the HTML that needs to be added to the 
// DOM. Use innerHTML or insertAdjacentHTML to append to DOM.
output.innerHTML = htmlBlock;

/**
 * CONST / LET
 */

// can't overwrite a const
const a = 10;
//a = 20 <-- this will cause an error
const obj = {
  a: 20
}
// You can overwrite a property of an object tho, only
// assigning a whole new object will trigger error
obj.a = 10;
const arr = [20, 30, 5];
// Same with array, you can edit a value inside of an array
// but you can't replace the array with 'arr = []';
arr[0] = 10;
arr.push(10);
console.log(arr);

// Curly brackets indicates a code block
// let creates a new scope inside of a code block
// a var or const will not create a new scope inside
// the block
if (true) {
  let c = 10;
}
// This won't work
console.log(c);


/** 
 * String and array operations
 */


// Create a new string
const string = "Hello my name is";

// Convert it to an array. This will produce an array that
// is split by each space: 
// ["Hello", "my", "name", "is"];
const converted = string.split(' ');

// .unshift inserts a new element at the first index
// of the array. 
converted.unshift('Haha');

// We can then join the array again. This will create a new
// string and store it in 'joined'
const joined = converted.join(' ');
// log it to see result
console.log(joined);

// If we have an array of numbers we cannot sort it
// by calling arr.sort(). 
const arr = [
  1,
  10,
  5,
  20
];

// The sad part is that .sort() always sort alfabetically
// so we have to supply an anonymous function
// that tells the function to sort is by numbers:
// Compare the current number (a) with the next number (b)
// and return true or false based on if it is bigger or not
// resulting in swapping places with higher and lower numbers
arr.sort(function (a, b) {
  return a > b;
});

// The array is now sorted
console.log(arr);