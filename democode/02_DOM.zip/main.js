const person = {
  name: "Jesper",
  age: 25,
  hobbies: [
    "Coding",
    "Eat",
    "Sleep"
  ],
  location: {
    town: "Uppsala",
    zipCode: 78998
  }
}

console.log(person.location.zipCode);

const newArray = [];

for (let hobby of person.hobbies){
  newArray.push(hobby);
}

newArray.push("Hej");

console.log(newArray);

const obj = { a: 5 };
const obj2 = obj;
obj2.a = 6;
delete obj.a;

console.log(obj, obj2);



// console.log(person.name);
// console.log(person.age);
// person.age = 30;
// console.log(person.age);
// console.log(person.hobbies);


const nav = document
  .getElementById('main-nav');

const links2 = document
  .getElementsByTagName('a');
  
const links = document
  .getElementsByClassName('nav-link');

for(const link of links){
  link.innerHTML = "<p>My new text</p>";
}

const nav = document
  .getElementById('main-nav');

console.log(nav.children);
console.log(nav.nextElementSibling.children);
console.log(nav.parentElement.parentElement);