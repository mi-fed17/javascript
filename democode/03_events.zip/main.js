const button = document
  .getElementById('button');
const input = document
  .getElementById('input');

const nav = document.
  getElementById("nav");

// Get all the links in the document
const aLinks = document
  .getElementsByTagName('a');

// Loop through every link, aLinks is an array
for(const link of aLinks){
  // Add an eventlistener to each element, each <a>-tag
  link.addEventListener('click', function() {

    // this is the easy way to toggle the style of an element
    this.classList.toggle('red');
    console.log(nav);
    // this is the awkward way of changing color of element
    // if(this.style.backgroundColor === "red"){
    //   this.style.backgroundColor = "white";
    // } else {
    //   this.style.backgroundColor = "red";
    // }
  });
}

// Listens to when input is deselected or 
// when enter is pressed
input.addEventListener('change', function(){
  // Create a new paragraph
  const paragraph = document
    .createElement('p');
  // Grab the value from the input element and set it 
  // to the newly created paragraph
  paragraph.innerText = input.value;
  // Add the paragraph to the <body>
  document.body.appendChild(paragraph);
})

// Listens to when the button is clicked
button.addEventListener('click', function(){
    const paragraph = document
    .createElement('p');
    paragraph.innerText = input.value;
    document.body.appendChild(paragraph);
    console.log(input.value);
});